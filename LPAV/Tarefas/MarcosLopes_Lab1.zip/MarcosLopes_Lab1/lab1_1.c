#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct evento_t{

    double temp;
    int alvo;
    int tipo;

}evento_t;

typedef struct lista_eventos_t{

    struct evento_t *evento;
    struct lista_eventos_t *prox;

}lista_eventos_t;

bool lista_eventos_adicionar_inicio(evento_t *evento, lista_eventos_t **lista){
    
    lista_eventos_t *item_novo = (lista_eventos_t*) malloc(sizeof(lista_eventos_t));

    if(!item_novo){
        return false;
    }else{

        item_novo->evento = evento;
        item_novo->prox = *lista;
        *lista = item_novo;
        return true;
    }

}

void lista_eventos_listar(lista_eventos_t *lista){

    int qtd = 0;
    lista_eventos_t *auxiliar = (lista_eventos_t *) malloc(sizeof(lista_eventos_t));
    
    auxiliar = lista;

    while(auxiliar){

        qtd++;
        printf("Temp: %3.6f, Alvo: %d, Tipo: %d\n",auxiliar->evento->temp,auxiliar->evento->alvo,auxiliar->evento->tipo);
        auxiliar = auxiliar->prox;
        
    }

    printf("Quantidade de eventos: %d\n",qtd);

}

int main(int argc, char **argv){
    lista_eventos_t **lista = (lista_eventos_t**) malloc(sizeof(lista_eventos_t**));

    *lista = NULL;

    double temp;
    int alvo,tipo;


    FILE * fp = fopen(argv[1], "r+");

    while(!feof(fp)){

        evento_t *evento = (evento_t*) malloc(sizeof(evento_t));
        fscanf(fp,"%lf\t%d\t%d\n",&temp,&alvo,&tipo);

        evento->temp = temp;
        evento->alvo = alvo;
        evento->tipo = tipo;

        lista_eventos_adicionar_inicio(evento,lista);

        
    }

    lista_eventos_listar(*lista);
    
}