#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct zip_file_hdr{
    int signature;
    short version;
    short flags;
    short compression;
    short mod_time;
    short mod_date;
    int crc;
    int compressed_size;
    int uncompressed_size;
    short name_length;
    short extra_field_length;
}__attribute__ ((packed));

int main(int argc, char **argv){

    FILE *zip_file = fopen(argv[1],"rb");

    while(feof(zip_file)){
        struct zip_file_hdr *aux = malloc(sizeof(struct zip_file_hdr));
        fread(aux,sizeof(struct zip_file_hdr),1,zip_file);
        if(aux->signature == 0x04034b50){
            char *nome = (char *) malloc(sizeof(char)*aux->name_length+1);
            fread(nome,sizeof(char)*aux->name_length,1,zip_file);
            nome[aux->name_length] = '\0';
            printf("Nome do arquivo: %s\n",nome);
            printf("Tamanho compactado: %d",aux->compressed_size);
            printf("Tamanho descompactado: %d",aux->uncompressed_size);
            free(nome);
            fseek(zip_file, aux->extra_field_length + aux->compressed_size, SEEK_CUR);
        }else break;
    }
    fclose(zip_file);
}